// Definição do Script

// Recuperando os dados da página
const dados = document.querySelector('#forms')

dados.addEventListener('submit', function(event){
    event.preventDefault();
    setMensagem('oi');
    getIMC();
});

    function getIMC() {
        const inPeso = document.querySelector('#peso');
        const inAltura = document.querySelector('#altura');


        const peso = Number(inPeso.value);
        const altura = Number(inAltura.value);

        if(!peso) {
            setMensagem('Peso Inválido');
            return;
        }

        if(!altura) {
            setMensagem('Altura Inválida');
            return;
        }
    }
function setMensagem (teste) {
    // Recupera a região para manipular as mensagens
    const msg = document.querySelector('#resultado');
    // Limpa a região
    msg.innerHTML = '';

    const frase = document.createElement('p');
    frase.classList.add('certo');
    msg.appendChild(frase);
    frase.innerHTML = teste;
}